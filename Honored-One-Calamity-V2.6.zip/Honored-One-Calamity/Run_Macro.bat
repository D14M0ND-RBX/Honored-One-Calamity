@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
    py honored_one_macro_v6_3.py
) else (
    python honored_one_macro_v6_3.py
)
pause
