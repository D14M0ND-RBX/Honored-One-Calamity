import os
import sys
import subprocess
import configparser
import tkinter as tk
from tkinter import ttk
import threading

# ============================================================
#  THE HONORED ONE - LAUNCHER
#  Writes settings.cfg which the macro reads on startup.
#  !! Roblox must be snapped to the LEFT HALF of your screen !!
# ============================================================

# ── Auto-install requirements on first run ────────────────────
def _install_requirements():
    req = os.path.join(os.path.dirname(__file__), "requirements.txt")
    if not os.path.exists(req):
        return
    print("[LAUNCHER] Installing/updating requirements...")
    subprocess.call([sys.executable, "-m", "pip", "install", "-r", req])

_install_requirements()

CFG_FILE = os.path.join(os.path.dirname(__file__), "settings.cfg")

# ------------------------------------------------------------------
# Reference values — captured on 3440x1440, Roblox left-half (1720x1440)
# Every pixel value is scaled from this baseline.
# ------------------------------------------------------------------
REF_GAME_W = 1720
REF_GAME_H = 1440

RESOLUTIONS = [
    ("1280x720",   1280,  720),
    ("1366x768",   1366,  768),
    ("1600x900",   1600,  900),
    ("1920x1080",  1920, 1080),
    ("2560x1080",  2560, 1080),
    ("2560x1440",  2560, 1440),
    ("3440x1440",  3440, 1440),
    ("3840x1080",  3840, 1080),
    ("3840x2160",  3840, 2160),
]

# Reference region coords (left, top, right, bottom) at 1720x1440
REF_REGIONS = {
    "open_map_honored":       (250,  90, 1880,  950),
    "click_honored":          (250, 100, 1880,  930),
    "honored_selected":       (700, 250, 1500,  750),
    "teleport_check":         (1450, 700, 1905, 930),
    "teleport_btn":           (1450, 680, 1910, 940),
    "calamity":               (850, 550, 1910,  850),
    "create":                 (1200, 850, 1910, 1070),
    "boss_bar":               (450,   0, 1650,  300),
    "hub":                    (150,  40,  650,  220),
    "countdown":              (350, 300, 1300,  650),
}

# Reference pixel values at 1720x1440
REF_VECTOR_ENTER_X        = 72
REF_VECTOR_ENTER_Y        = 42
REF_VECTOR_X_DEADBAND     = 125
REF_VECTOR_Y_DEADBAND     = 62
REF_CIRCLE_TOLERANCE_X    = 70
REF_CIRCLE_TOLERANCE_Y    = 60
REF_CONTOUR_AREA_MIN      = 900
REF_CONTOUR_W_MIN         = 110
REF_CONTOUR_H_MIN         = 28


def scale(ref_val, factor):
    return int(round(ref_val * factor))


def compute_settings(total_w, total_h,
                     vector_alpha, raid_timeout,
                     mask_top, mask_bottom,
                     fallback_top, fallback_bottom,
                     threshold_honored, threshold_boss, threshold_hub,
                     click_honored_x, click_honored_y,
                     click_teleport_x, click_teleport_y,
                     click_calamity_x, click_calamity_y,
                     click_create_x, click_create_y,
                     click_return_x, click_return_y,
                     attack_keys, ten_shadows, raid_counter):
    """Return a flat dict of every setting the macro needs."""

    # Half-screen game window
    game_w = total_w // 2
    game_h = total_h

    sx = game_w / REF_GAME_W
    sy = game_h / REF_GAME_H
    sa = sx * sy

    cfg = {}

    cfg["total_w"] = total_w
    cfg["total_h"] = total_h
    cfg["game_w"]  = game_w
    cfg["game_h"]  = game_h

    # Attack keys
    for k, v in attack_keys.items():
        cfg[f"attack_{k}"] = "true" if v else "false"
    # domain derived from T key for legacy header
    cfg["domain"] = "true" if attack_keys.get("t", False) else "false"
    # ten_shadows flag — macro uses this to exclude Y from rotation mid-fight
    cfg["ten_shadows"] = "true" if ten_shadows else "false"
    # raid counter overlay
    cfg["raid_counter"] = "true" if raid_counter else "false"

    # player_x — centre of the half-screen game window
    cfg["player_x"] = game_w // 2

    # HSV mask percentages
    cfg["mask_top"]        = round(mask_top, 3)
    cfg["mask_bottom"]     = round(mask_bottom, 3)
    cfg["fallback_top"]    = round(fallback_top, 3)
    cfg["fallback_bottom"] = round(fallback_bottom, 3)

    # Scaled pixel values
    cfg["vector_enter_x"]     = scale(REF_VECTOR_ENTER_X,     sx)
    cfg["vector_enter_y"]     = scale(REF_VECTOR_ENTER_Y,     sy)
    cfg["vector_x_deadband"]  = scale(REF_VECTOR_X_DEADBAND,  sx)
    cfg["vector_y_deadband"]  = scale(REF_VECTOR_Y_DEADBAND,  sy)
    cfg["circle_tolerance_x"] = scale(REF_CIRCLE_TOLERANCE_X, sx)
    cfg["circle_tolerance_y"] = scale(REF_CIRCLE_TOLERANCE_Y, sy)
    cfg["contour_area_min"]   = int(round(REF_CONTOUR_AREA_MIN * sa))
    cfg["contour_w_min"]      = scale(REF_CONTOUR_W_MIN, sx)
    cfg["contour_h_min"]      = scale(REF_CONTOUR_H_MIN, sy)

    # Advanced tunable values
    cfg["vector_alpha"]      = round(vector_alpha, 3)
    cfg["raid_timeout"]      = int(raid_timeout)
    cfg["threshold_honored"] = round(threshold_honored, 2)
    cfg["threshold_boss"]    = round(threshold_boss, 2)
    cfg["threshold_hub"]     = round(threshold_hub, 2)

    # Mouse click coords (user-entered, exact — no scaling)
    cfg["click_honored_x"]   = int(click_honored_x)
    cfg["click_honored_y"]   = int(click_honored_y)
    cfg["click_teleport_x"]  = int(click_teleport_x)
    cfg["click_teleport_y"]  = int(click_teleport_y)
    cfg["click_calamity_x"]  = int(click_calamity_x)
    cfg["click_calamity_y"]  = int(click_calamity_y)
    cfg["click_create_x"]    = int(click_create_x)
    cfg["click_create_y"]    = int(click_create_y)
    cfg["click_return_x"]    = int(click_return_x)
    cfg["click_return_y"]    = int(click_return_y)

    # Scaled regions
    for key, (l, t, r, b) in REF_REGIONS.items():
        cfg[f"region_{key}"] = (
            scale(l, sx), scale(t, sy),
            scale(r, sx), scale(b, sy),
        )

    return cfg


def write_cfg(cfg):
    parser = configparser.ConfigParser()
    parser["macro"] = {}
    for k, v in cfg.items():
        if isinstance(v, tuple):
            parser["macro"][k] = ",".join(str(x) for x in v)
        else:
            parser["macro"][k] = str(v)
    with open(CFG_FILE, "w") as f:
        parser.write(f)
    print(f"[LAUNCHER] settings.cfg written to {CFG_FILE}")


def read_cfg():
    """Load previously saved settings from settings.cfg into a flat dict."""
    if not os.path.exists(CFG_FILE):
        return {}
    parser = configparser.ConfigParser()
    parser.read(CFG_FILE)
    if "macro" not in parser:
        return {}
    return dict(parser["macro"])


# ------------------------------------------------------------------
# GUI
# ------------------------------------------------------------------

BG       = "#1a1a1a"
FG       = "#cccccc"
FG_DIM   = "#666666"
FG_WHITE = "#ffffff"
FG_MUT   = "#888888"
ACCENT   = "#2e6fdb"
ACCENT_H = "#1e5cc7"
SURFACE  = "#242424"
BORDER   = "#333333"
FONT     = ("Segoe UI", 10)
FONT_SM  = ("Segoe UI", 8)


def make_label(parent, text, font=None, fg=None, **kw):
    return tk.Label(parent, text=text,
                    bg=BG, fg=fg or FG,
                    font=font or FONT, **kw)


def make_entry(parent, var, width=10):
    return tk.Entry(parent, textvariable=var,
                    bg=SURFACE, fg=FG_WHITE,
                    insertbackground=FG_WHITE,
                    relief="flat", font=FONT,
                    width=width,
                    highlightbackground=BORDER,
                    highlightthickness=1)


def build_gui():
    root = tk.Tk()
    root.title("THE HONORED ONE — Launcher")
    root.resizable(False, False)
    root.configure(bg=BG)

    # ── Title ──────────────────────────────────────────────────────
    tk.Label(root, text="THE HONORED ONE", bg=BG, fg=FG_WHITE,
             font=("Segoe UI", 14, "bold")).grid(
        row=0, column=0, columnspan=2, pady=(18, 2))
    tk.Label(root, text="AUTO CALAMITY RAID v2.6",
             bg=BG, fg=FG_MUT, font=FONT_SM).grid(
        row=1, column=0, columnspan=2, pady=(0, 4))
    tk.Label(root,
             text="!! Roblox must be snapped to the LEFT HALF of your screen !!",
             bg=BG, fg="#e05252", font=("Segoe UI", 8, "bold")).grid(
        row=2, column=0, columnspan=2, pady=(0, 12))

    ttk.Separator(root, orient="horizontal").grid(
        row=3, column=0, columnspan=2, sticky="ew", padx=20, pady=(0, 12))

    pad   = {"padx": (20, 8), "pady": 5}
    pad_r = {"padx": (0, 20), "pady": 5}

    # ── Resolution ─────────────────────────────────────────────────
    make_label(root, "Resolution :").grid(row=4, column=0, sticky="e", **pad)
    res_labels = [r[0] for r in RESOLUTIONS]
    res_var = tk.StringVar(value="3440x1440")
    res_cb = ttk.Combobox(root, textvariable=res_var, values=res_labels,
                          state="readonly", width=14, font=FONT)
    res_cb.grid(row=4, column=1, sticky="w", **pad_r)

    # ── Raid Counter toggle ────────────────────────────────────────
    raid_counter_var = tk.BooleanVar(value=False)
    raid_counter_sym = tk.Label(root, text="✗", bg=BG, fg="#e05252",
                                font=("Segoe UI", 9, "bold"), width=2)
    raid_counter_sym.grid(row=5, column=0, sticky="e", padx=(20, 0), pady=4)

    def on_raid_counter_toggle():
        v = raid_counter_var.get()
        raid_counter_sym.config(text="✓" if v else "✗",
                                fg="#5ec45e" if v else "#e05252")

    tk.Checkbutton(root, text="Raid Counter overlay", variable=raid_counter_var,
                   bg=BG, fg=FG, selectcolor=SURFACE, activebackground=BG,
                   font=FONT_SM, command=on_raid_counter_toggle).grid(
        row=5, column=1, sticky="w", padx=(0, 20), pady=4)

    ttk.Separator(root, orient="horizontal").grid(
        row=6, column=0, columnspan=2, sticky="ew", padx=20, pady=(4, 4))

    # ── Cursed Technique toggle ────────────────────────────────────
    ct_open = tk.BooleanVar(value=False)
    ct_frame = tk.Frame(root, bg=BG)

    def toggle_ct():
        if ct_open.get():
            ct_frame.grid_remove()
            ct_open.set(False)
            ct_btn.config(text="▶  Cursed Technique")
        else:
            ct_frame.grid(row=8, column=0, columnspan=2,
                          sticky="ew", padx=20, pady=(0, 4))
            ct_open.set(True)
            ct_btn.config(text="▼  Cursed Technique")
        root.update_idletasks()
        _centre(root)

    ct_btn = tk.Button(root, text="▶  Cursed Technique",
                       command=toggle_ct,
                       bg=BG, fg=FG_MUT, font=FONT_SM,
                       relief="flat", cursor="hand2",
                       activebackground=BG, activeforeground=FG)
    ct_btn.grid(row=7, column=0, columnspan=2, pady=(2, 2))

    CT_LIST = [
        "Ten Shadows",
        "Awk Limitless",
        "Awk Star Rage",
        "Awk Blood-Manip",
        "Shrine",
        "Limitless",
        "Projection Sorcery",
    ]
    ct_vars   = {}   # ct_name -> BooleanVar
    ct_syms   = {}   # ct_name -> sym Label
    ct_cbs    = {}   # ct_name -> Checkbutton widget
    selected_ct = tk.StringVar(value="")  # only one at a time

    def on_ct_click(chosen):
        # Deselect all others
        for name, var in ct_vars.items():
            if name != chosen:
                var.set(False)
                ct_syms[name].config(text="✗", fg="#e05252")
        # Update Y lock based on Ten Shadows
        is_ten = ct_vars["Ten Shadows"].get()
        if is_ten:
            # Force Y on and grey it out — Ten Shadows needs Y at end of script
            atk_vars["y"].set(True)
            y_sym.config(text="✓", fg="#5ec45e")
            y_cb.config(state="disabled")
        else:
            # Any other CT (or none) — let the player choose Y freely
            atk_vars["y"].set(False)
            y_sym.config(text="✗", fg="#e05252")
            y_cb.config(state="normal")

    for i, ct in enumerate(CT_LIST):
        v = tk.BooleanVar(value=False)
        ct_vars[ct] = v
        row_f = tk.Frame(ct_frame, bg=BG)
        row_f.grid(row=i, column=0, columnspan=2, sticky="w", padx=4, pady=2)
        sym = tk.Label(row_f, text="✗", bg=BG, fg="#e05252",
                       font=("Segoe UI", 9, "bold"), width=2)
        sym.pack(side="left")
        ct_syms[ct] = sym
        cb = tk.Checkbutton(row_f, text=ct, variable=v, bg=BG, fg=FG,
                            selectcolor=SURFACE, activebackground=BG,
                            font=FONT_SM,
                            command=lambda name=ct, lbl=sym, var=v: (
                                lbl.config(text="✓" if var.get() else "✗",
                                           fg="#5ec45e" if var.get() else "#e05252"),
                                on_ct_click(name)
                            ))
        cb.pack(side="left")
        ct_cbs[ct] = cb

    ttk.Separator(root, orient="horizontal").grid(
        row=9, column=0, columnspan=2, sticky="ew", padx=20, pady=(6, 4))

    # ── Attacks toggle ─────────────────────────────────────────────
    atk_open = tk.BooleanVar(value=False)
    atk_frame = tk.Frame(root, bg=BG)

    def toggle_atk():
        if atk_open.get():
            atk_frame.grid_remove()
            atk_open.set(False)
            atk_btn.config(text="▶  Attacks")
        else:
            atk_frame.grid(row=11, column=0, columnspan=2,
                           sticky="ew", padx=20, pady=(0, 4))
            atk_open.set(True)
            atk_btn.config(text="▼  Attacks")
        root.update_idletasks()
        _centre(root)

    atk_btn = tk.Button(root, text="▶  Attacks",
                        command=toggle_atk,
                        bg=BG, fg=FG_MUT, font=FONT_SM,
                        relief="flat", cursor="hand2",
                        activebackground=BG, activeforeground=FG)
    atk_btn.grid(row=10, column=0, columnspan=2, pady=(2, 2))

    ATK_LIST = [
        ("Z",          "z",  True),
        ("V",          "v",  True),
        ("Y",          "y",  False),   # controlled by Ten Shadows
        ("T (Domain)", "t",  False),
        ("F",          "f",  True),
        ("C",          "c",  True),
        ("X",          "x",  True),
        ("R",          "r",  True),
    ]
    atk_vars = {}
    atk_syms = {}   # key -> sym Label, for restore
    y_sym = None
    y_cb  = None
    for i, (label, key, default) in enumerate(ATK_LIST):
        v = tk.BooleanVar(value=default)
        atk_vars[key] = v
        row_f = tk.Frame(atk_frame, bg=BG)
        row_f.grid(row=i, column=0, columnspan=2, sticky="w", padx=4, pady=2)
        sym = tk.Label(row_f, text="✓" if default else "✗", bg=BG,
                       fg="#5ec45e" if default else "#e05252",
                       font=("Segoe UI", 9, "bold"), width=2)
        sym.pack(side="left")
        atk_syms[key] = sym
        cb = tk.Checkbutton(row_f, text=label, variable=v, bg=BG, fg=FG,
                            selectcolor=SURFACE, activebackground=BG,
                            font=FONT_SM,
                            command=lambda s=sym, var=v: s.config(
                                text="✓" if var.get() else "✗",
                                fg="#5ec45e" if var.get() else "#e05252"))
        cb.pack(side="left")
        if key == "y":
            y_sym = sym
            y_cb  = cb
            # starts enabled; locked only when Ten Shadows is ticked

    ttk.Separator(root, orient="horizontal").grid(
        row=12, column=0, columnspan=2, sticky="ew", padx=20, pady=(6, 4))

    # ── Mouse Clicks toggle ────────────────────────────────────────
    clicks_open = tk.BooleanVar(value=False)
    clicks_frame = tk.Frame(root, bg=BG)

    def toggle_clicks():
        if clicks_open.get():
            clicks_frame.grid_remove()
            clicks_open.set(False)
            clicks_btn.config(text="▶  Mouse Clicks")
        else:
            clicks_frame.grid(row=14, column=0, columnspan=2,
                              sticky="ew", padx=20, pady=(0, 6))
            clicks_open.set(True)
            clicks_btn.config(text="▼  Mouse Clicks")
        root.update_idletasks()
        _centre(root)

    clicks_btn = tk.Button(root, text="▶  Mouse Clicks",
                           command=toggle_clicks,
                           bg=BG, fg=FG_MUT, font=FONT_SM,
                           relief="flat", cursor="hand2",
                           activebackground=BG, activeforeground=FG)
    clicks_btn.grid(row=13, column=0, columnspan=2, pady=(2, 2))

    # ── Mouse click fields ─────────────────────────────────────────
    click_vars = {}

    # Header row
    tk.Label(clicks_frame, text="Button", bg=BG, fg=FG_MUT,
             font=("Segoe UI", 8, "bold")).grid(row=0, column=0, sticky="e", padx=(0, 8), pady=(2, 4))
    tk.Label(clicks_frame, text="X", bg=BG, fg=FG_MUT,
             font=("Segoe UI", 8, "bold")).grid(row=0, column=1, sticky="w", padx=(0, 4), pady=(2, 4))
    tk.Label(clicks_frame, text="Y", bg=BG, fg=FG_MUT,
             font=("Segoe UI", 8, "bold")).grid(row=0, column=2, sticky="w", pady=(2, 4))

    def click_row(parent, label, key, def_x, def_y, row):
        tk.Label(parent, text=label, bg=BG, fg=FG_MUT,
                 font=FONT_SM).grid(row=row, column=0, sticky="e", padx=(0, 8), pady=3)
        vx = tk.StringVar(value=str(def_x))
        vy = tk.StringVar(value=str(def_y))
        click_vars[f"{key}_x"] = vx
        click_vars[f"{key}_y"] = vy
        tk.Entry(parent, textvariable=vx, bg=SURFACE, fg=FG_WHITE,
                 insertbackground=FG_WHITE, relief="flat", font=FONT_SM,
                 width=6, highlightbackground=BORDER,
                 highlightthickness=1).grid(row=row, column=1, sticky="w", padx=(0, 4), pady=3)
        tk.Entry(parent, textvariable=vy, bg=SURFACE, fg=FG_WHITE,
                 insertbackground=FG_WHITE, relief="flat", font=FONT_SM,
                 width=6, highlightbackground=BORDER,
                 highlightthickness=1).grid(row=row, column=2, sticky="w", pady=3)

    click_row(clicks_frame, "honored_sword_new :", "honored",  0, 0, 1)
    click_row(clicks_frame, "teleport_button    :", "teleport", 0, 0, 2)
    click_row(clicks_frame, "calamity_button    :", "calamity", 0, 0, 3)
    click_row(clicks_frame, "create_button      :", "create",   0, 0, 4)
    click_row(clicks_frame, "return_button      :", "return",   0, 0, 5)

    tk.Label(clicks_frame,
             text="Use F9 in the macro to get coords. Enter 0 to use auto-detection.",
             bg=BG, fg="#555555", font=("Segoe UI", 7)).grid(
        row=6, column=0, columnspan=3, pady=(4, 2))

    # ── Mouse Clicks toggle (shifted down) ────────────────────────
    # ── Advanced toggle ────────────────────────────────────────────
    adv_open = tk.BooleanVar(value=False)
    adv_frame = tk.Frame(root, bg=BG)

    def toggle_adv():
        if adv_open.get():
            adv_frame.grid_remove()
            adv_open.set(False)
            adv_btn.config(text="▶  Advanced Settings")
        else:
            adv_frame.grid(row=16, column=0, columnspan=2,
                           sticky="ew", padx=20, pady=(0, 6))
            adv_open.set(True)
            adv_btn.config(text="▼  Advanced Settings")
        root.update_idletasks()
        _centre(root)

    adv_btn = tk.Button(root, text="▶  Advanced Settings",
                        command=toggle_adv,
                        bg=BG, fg=FG_MUT, font=FONT_SM,
                        relief="flat", cursor="hand2",
                        activebackground=BG, activeforeground=FG)
    adv_btn.grid(row=15, column=0, columnspan=2, pady=(2, 4))

    # ── Advanced fields ────────────────────────────────────────────
    adv_vars = {}

    def adv_row(parent, label, key, default, row):
        make_label(parent, label, fg=FG_MUT).grid(
            row=row, column=0, sticky="e", padx=(0, 8), pady=3)
        v = tk.StringVar(value=str(default))
        adv_vars[key] = v
        make_entry(parent, v, width=9).grid(
            row=row, column=1, sticky="w", pady=3)

    adv_row(adv_frame, "VECTOR_ALPHA",        "vector_alpha",    0.58,  0)
    adv_row(adv_frame, "RAID_START_TIMEOUT",  "raid_timeout",    75,    1)
    adv_row(adv_frame, "Threshold : honored", "thr_honored",     0.62,  2)
    adv_row(adv_frame, "Threshold : boss",    "thr_boss",        0.62,  3)
    adv_row(adv_frame, "Threshold : hub",     "thr_hub",         0.65,  4)
    adv_row(adv_frame, "Mask top %",          "mask_top",        0.30,  5)
    adv_row(adv_frame, "Mask bottom %",       "mask_bottom",     0.91,  6)
    adv_row(adv_frame, "Fallback top %",      "fallback_top",    0.27,  7)
    adv_row(adv_frame, "Fallback bottom %",   "fallback_bottom", 0.90,  8)

    ttk.Separator(root, orient="horizontal").grid(
        row=17, column=0, columnspan=2, sticky="ew", padx=20, pady=(8, 8))

    # ── Status label ───────────────────────────────────────────────
    status_var = tk.StringVar(value="")
    tk.Label(root, textvariable=status_var, bg=BG, fg="#5ec45e",
             font=FONT_SM).grid(row=18, column=0, columnspan=2, pady=(0, 4))

    # ── Preview overlay ────────────────────────────────────────────
    _preview_active = {"on": False, "win": None}

    def show_preview():
        if _preview_active["on"]:
            try:
                _preview_active["win"].destroy()
            except Exception:
                pass
            _preview_active["on"] = False
            _preview_active["win"] = None
            preview_btn.config(text="👁  Preview Regions")
            return

        sel = res_var.get()
        match_r = next((r for r in RESOLUTIONS if r[0] == sel), None)
        if not match_r:
            return
        _, total_w, total_h = match_r
        game_w = total_w // 2
        sx = game_w / REF_GAME_W
        sy = total_h / REF_GAME_H

        regions = {}
        for key, (l, t, r, b) in REF_REGIONS.items():
            regions[key] = (
                int(round(l * sx)), int(round(t * sy)),
                int(round(r * sx)), int(round(b * sy)),
            )

        COLOURS = {
            "open_map_honored":  "#ff4444",
            "click_honored":     "#ff8800",
            "honored_selected":  "#ffcc00",
            "teleport_check":    "#44ff44",
            "teleport_btn":      "#00cc44",
            "calamity":          "#44ccff",
            "create":            "#4488ff",
            "boss_bar":          "#cc44ff",
            "hub":               "#ff44cc",
            "countdown":         "#ffffff",
        }

        ov = tk.Toplevel(root)
        ov.overrideredirect(True)
        ov.attributes("-topmost", True)
        ov.attributes("-transparentcolor", "#000001")
        ov.geometry(f"{game_w}x{total_h}+0+0")
        ov.configure(bg="#000001")

        canvas = tk.Canvas(ov, width=game_w, height=total_h,
                           bg="#000001", highlightthickness=0)
        canvas.pack()

        for key, (l, t, r, b) in regions.items():
            colour = COLOURS.get(key, "#ffffff")
            canvas.create_rectangle(l, t, r, b, outline=colour, width=2, fill="")
            canvas.create_text(l + 4, t + 4, anchor="nw",
                               text=key, fill=colour,
                               font=("Segoe UI", 7, "bold"))

        canvas.bind("<Button-1>", lambda e: show_preview())

        _preview_active["on"] = True
        _preview_active["win"] = ov
        preview_btn.config(text="✕  Close Preview")

    preview_btn = tk.Button(root, text="👁  Preview Regions",
                            command=show_preview,
                            bg=SURFACE, fg=FG,
                            font=FONT_SM,
                            relief="flat", padx=12, pady=5,
                            cursor="hand2",
                            activebackground=BORDER,
                            activeforeground=FG_WHITE)
    preview_btn.grid(row=19, column=0, columnspan=2, pady=(0, 6))

    # ── Save button ────────────────────────────────────────────────
    def on_save():
        sel = res_var.get()
        match = next((r for r in RESOLUTIONS if r[0] == sel), None)
        if not match:
            return
        _, total_w, total_h = match

        try:
            va   = float(adv_vars["vector_alpha"].get())
            rt   = int(adv_vars["raid_timeout"].get())
            mt   = float(adv_vars["mask_top"].get())
            mb   = float(adv_vars["mask_bottom"].get())
            ft   = float(adv_vars["fallback_top"].get())
            fb   = float(adv_vars["fallback_bottom"].get())
            th   = float(adv_vars["thr_honored"].get())
            tb   = float(adv_vars["thr_boss"].get())
            thub = float(adv_vars["thr_hub"].get())
            hx   = int(click_vars["honored_x"].get())
            hy   = int(click_vars["honored_y"].get())
            tx   = int(click_vars["teleport_x"].get())
            ty   = int(click_vars["teleport_y"].get())
            cx   = int(click_vars["calamity_x"].get())
            cy   = int(click_vars["calamity_y"].get())
            crx  = int(click_vars["create_x"].get())
            cry  = int(click_vars["create_y"].get())
            rx   = int(click_vars["return_x"].get())
            ry   = int(click_vars["return_y"].get())
        except ValueError:
            status_var.set("⚠  Invalid value — check all fields.")
            return

        attack_keys = {k: v.get() for k, v in atk_vars.items()}
        is_ten_shadows = ct_vars["Ten Shadows"].get()
        print(f"[DEBUG] is_ten_shadows={is_ten_shadows}, attack_y={attack_keys.get('y')}")

        is_raid_counter = raid_counter_var.get()

        cfg = compute_settings(total_w, total_h,
                               va, rt, mt, mb, ft, fb, th, tb, thub,
                               hx, hy, tx, ty, cx, cy, crx, cry, rx, ry,
                               attack_keys, is_ten_shadows, is_raid_counter)
        write_cfg(cfg)
        status_var.set(f"✔  Saved! Launching macro...")

        def launch():
            root.destroy()
            macro = os.path.join(os.path.dirname(__file__), "honored_one_macro_v6_3.py")
            subprocess.Popen(
                [sys.executable, macro],
                creationflags=subprocess.CREATE_NEW_CONSOLE
            )

        root.after(800, launch)

    tk.Button(root, text="SAVE & LAUNCH",
              command=on_save,
              bg=ACCENT, fg=FG_WHITE,
              font=("Segoe UI", 11, "bold"),
              relief="flat", padx=20, pady=8,
              cursor="hand2",
              activebackground=ACCENT_H,
              activeforeground=FG_WHITE).grid(
        row=20, column=0, columnspan=2, pady=(0, 20))

    # ── Restore saved settings from settings.cfg ───────────────────
    _saved = read_cfg()
    if _saved:
        # Resolution
        _tw = _saved.get("total_w", "")
        _th = _saved.get("total_h", "")
        if _tw and _th:
            _game_w = int(_tw) // 2
            _match = next((r for r in RESOLUTIONS if r[1] == int(_tw) and r[2] == int(_th)), None)
            if _match:
                res_var.set(_match[0])

        # Raid counter
        _rc = _saved.get("raid_counter", "false").strip().lower() == "true"
        if _rc:
            raid_counter_var.set(True)
            raid_counter_sym.config(text="✓", fg="#5ec45e")

        # Cursed Technique — restore which one was selected
        _ten = _saved.get("ten_shadows", "false").strip().lower() == "true"
        if _ten:
            ct_vars["Ten Shadows"].set(True)
            ct_syms["Ten Shadows"].config(text="✓", fg="#5ec45e")
            # re-run Y lock logic
            atk_vars["y"].set(True)
            y_sym.config(text="✓", fg="#5ec45e")
            y_cb.config(state="disabled")

        # Attack keys — restore values and update sym icons
        for key, var in atk_vars.items():
            _val = _saved.get(f"attack_{key}", "").strip().lower()
            if _val in ("true", "false"):
                var.set(_val == "true")
                _v = _val == "true"
                atk_syms[key].config(text="✓" if _v else "✗",
                                     fg="#5ec45e" if _v else "#e05252")

        # Click coords
        for key in ("honored", "teleport", "calamity", "create", "return"):
            _x = _saved.get(f"click_{key}_x", "0")
            _y = _saved.get(f"click_{key}_y", "0")
            click_vars[f"{key}_x"].set(_x)
            click_vars[f"{key}_y"].set(_y)

        # Advanced settings
        _adv_map = {
            "vector_alpha":    "vector_alpha",
            "raid_timeout":    "raid_timeout",
            "thr_honored":     "threshold_honored",
            "thr_boss":        "threshold_boss",
            "thr_hub":         "threshold_hub",
            "mask_top":        "mask_top",
            "mask_bottom":     "mask_bottom",
            "fallback_top":    "fallback_top",
            "fallback_bottom": "fallback_bottom",
        }
        for adv_key, cfg_key in _adv_map.items():
            _val = _saved.get(cfg_key, "")
            if _val:
                adv_vars[adv_key].set(_val)

    _centre(root)
    root.mainloop()


def _centre(root):
    root.update_idletasks()
    w = root.winfo_reqwidth()
    h = root.winfo_reqheight()
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    root.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")


if __name__ == "__main__":
    build_gui()
