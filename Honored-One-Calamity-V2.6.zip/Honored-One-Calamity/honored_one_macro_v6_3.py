import os
import sys
import ctypes
import configparser
import time
import math
import threading
from pathlib import Path

import cv2
import keyboard
import numpy as np
import pyautogui
import pydirectinput
import pygetwindow as gw

# ============================================================
# THE HONORED ONE - AUTO CALAMITY RAID v2.6
# ============================================================
#
# Main v6.3 changes:
# - Improved circle detector retained; WASD vector steering restored.
# - Uses new tight templates from the latest map screenshots.
# - Searches the whole map for The Honored One instead of assuming
#   the icon is at one fixed position.
# - Uses multi-scale template matching, so different map zoom levels
#   are tolerated.
# - Verifies the selected Honored One panel appears before trying
#   to press Teleport.
# - Searches the lower-right panel specifically for Teleport.
#
# F6 = Start / Pause
# F7 = Emergency Stop
# F8 = Force new cycle
# F9 = Mouse position
# ============================================================

ROOT = Path(__file__).resolve().parent

# ── Load settings.cfg written by launcher.py ─────────────────────────────────
def _load_cfg():
    cfg_path = ROOT / "settings.cfg"
    if not cfg_path.exists():
        print("[WARN] settings.cfg not found — using built-in defaults.")
        print("[WARN] Run launcher.py first to configure your resolution.")
        return {}
    p = configparser.ConfigParser()
    p.read(str(cfg_path))
    return dict(p["macro"]) if "macro" in p else {}

def _ri(d, key, default):
    """Read int from cfg dict."""
    try: return int(d[key])
    except (KeyError, ValueError): return default

def _rf(d, key, default):
    """Read float from cfg dict."""
    try: return float(d[key])
    except (KeyError, ValueError): return default

def _rb(d, key, default):
    """Read bool from cfg dict."""
    try: return d[key].strip().lower() == "true"
    except KeyError: return default

def _rr(d, key, default):
    """Read region tuple (l,t,r,b) from cfg dict."""
    try:
        parts = d[key].split(",")
        return tuple(int(x) for x in parts)
    except (KeyError, ValueError): return default

_CFG = _load_cfg()

# ── Settings — overridden by launcher if settings.cfg exists ─────────────────
DOMAIN_ENABLED        = _rb(_CFG, "domain",           False)
TEN_SHADOWS           = _rb(_CFG, "ten_shadows",       False)
RAID_COUNTER_ENABLED  = _rb(_CFG, "raid_counter",      False)

# Attack keys — which keys to spam (read from cfg, fallback to all enabled)
ATTACK_KEYS = {
    "z": _rb(_CFG, "attack_z", True),
    "v": _rb(_CFG, "attack_v", True),
    "y": _rb(_CFG, "attack_y", False),
    "t": _rb(_CFG, "attack_t", DOMAIN_ENABLED),
    "f": _rb(_CFG, "attack_f", True),
    "c": _rb(_CFG, "attack_c", True),
    "x": _rb(_CFG, "attack_x", True),
    "r": _rb(_CFG, "attack_r", True),
}
VECTOR_ALPHA          = _rf(_CFG, "vector_alpha",      0.58)
RAID_START_TIMEOUT    = _ri(_CFG, "raid_timeout",      75)
VECTOR_ENTER_X        = _ri(_CFG, "vector_enter_x",    72)
VECTOR_ENTER_Y        = _ri(_CFG, "vector_enter_y",    42)
VECTOR_X_DEADBAND     = _ri(_CFG, "vector_x_deadband", 125)
VECTOR_Y_DEADBAND     = _ri(_CFG, "vector_y_deadband", 62)
CIRCLE_CENTER_TOLERANCE_X = _ri(_CFG, "circle_tolerance_x", 70)
CIRCLE_CENTER_TOLERANCE_Y = _ri(_CFG, "circle_tolerance_y", 60)
CONTOUR_AREA_MIN      = _ri(_CFG, "contour_area_min",  900)
CONTOUR_W_MIN         = _ri(_CFG, "contour_w_min",     110)
CONTOUR_H_MIN         = _ri(_CFG, "contour_h_min",     28)
MASK_TOP              = _rf(_CFG, "mask_top",           0.30)
MASK_BOTTOM           = _rf(_CFG, "mask_bottom",        0.91)
FALLBACK_TOP          = _rf(_CFG, "fallback_top",       0.27)
FALLBACK_BOTTOM       = _rf(_CFG, "fallback_bottom",    0.90)
PLAYER_X_OVERRIDE     = _ri(_CFG, "player_x",          0)   # 0 = use sw//4
THR_HONORED           = _rf(_CFG, "threshold_honored",  0.62)
THR_BOSS              = _rf(_CFG, "threshold_boss",     0.62)
THR_HUB               = _rf(_CFG, "threshold_hub",      0.65)

# Regions
R_OPEN_MAP_HONORED = _rr(_CFG, "region_open_map_honored", (250,  90, 1880,  950))
R_CLICK_HONORED    = _rr(_CFG, "region_click_honored",    (250, 100, 1880,  930))
R_HONORED_SELECTED = _rr(_CFG, "region_honored_selected", (700, 250, 1500,  750))
R_TELEPORT_CHECK   = _rr(_CFG, "region_teleport_check",   (1450,700, 1905,  930))
R_TELEPORT_BTN     = _rr(_CFG, "region_teleport_btn",     (1450,680, 1910,  940))
R_CALAMITY         = _rr(_CFG, "region_calamity",         (850, 550, 1910,  850))
R_CREATE           = _rr(_CFG, "region_create",           (1200,850, 1910, 1070))
R_BOSS_BAR         = _rr(_CFG, "region_boss_bar",         (450,   0, 1650,  300))
R_HUB              = _rr(_CFG, "region_hub",              (150,  40,  650,  220))
R_COUNTDOWN        = _rr(_CFG, "region_countdown",        (350, 300, 1300,  650))

TEMPLATE_FILES = {
    "honored": ROOT / "honored_sword_new.png",
    "honored_selected": ROOT / "honored_sword_selected.png",
    "teleport": ROOT / "teleport_button_new.png",
    "calamity": ROOT / "calamity_button.png",
    "create": ROOT / "create_button.png",
    "hub": ROOT / "hub_buttons.png",
    "boss": ROOT / "boss_bar.png",
    "circle": ROOT / "blue_raid_circle.png",
    "circle_close": ROOT / "blue_raid_circle_close.png",
    "circle_v2": ROOT / "blue_raid_circle_v2.png",
    "circle_far": ROOT / "blue_raid_circle_far.png",
    "starting_in": ROOT / "starting_in_text.png",
}

REF_W = 1919
REF_H = 1079

# Calamity / Create fallback coords (used only if cfg returns 0).
CALAMITY_REF  = (1582, 882)
CREATE_REF    = (1446, 1119)
REF_CLICK_W   = 1920
REF_CLICK_H   = 1080

# Click coords from cfg (0 = not set, falls back to scaled ref)
CLICK_HONORED_X  = _ri(_CFG, "click_honored_x",  0)
CLICK_HONORED_Y  = _ri(_CFG, "click_honored_y",  0)
CLICK_TELEPORT_X = _ri(_CFG, "click_teleport_x", 0)
CLICK_TELEPORT_Y = _ri(_CFG, "click_teleport_y", 0)
CLICK_CALAMITY_X = _ri(_CFG, "click_calamity_x", 0)
CLICK_CALAMITY_Y = _ri(_CFG, "click_calamity_y", 0)
CLICK_CREATE_X   = _ri(_CFG, "click_create_x",   0)
CLICK_CREATE_Y   = _ri(_CFG, "click_create_y",   0)
CLICK_RETURN_X   = _ri(_CFG, "click_return_x",   0)
CLICK_RETURN_Y   = _ri(_CFG, "click_return_y",   0)

ABILITY_KEY_DELAY = 0.18
WALK_TO_STRUCTURE_SECONDS = 0.0
PRE_CIRCLE_LEFT_SECONDS = 1.0
PRE_CIRCLE_BACK_SECONDS = 1.5
CIRCLE_SETTLE_CHECKS = 3

# Vector circle tracker
VECTOR_TRACK_TIMEOUT = 12.0
VECTOR_LOST_TIMEOUT = 1.25
VECTOR_VELOCITY_ALPHA = 0.35
VECTOR_PREDICT_SECONDS = 0.10
VECTOR_INSIDE_CONFIRMATIONS = 4

VECTOR_STEP_FAR = 0.16
VECTOR_STEP_MEDIUM = 0.08
VECTOR_STEP_NEAR = 0.03

ALIGN_BAND_CLOSE = 95
ALIGN_BAND_MEDIUM = 130
ALIGN_BAND_FAR = 175

STEP_FAR = 0.34
STEP_MEDIUM = 0.22
STEP_NEAR = 0.12
TELEPORT_LOAD_WAIT = 3.5
MENU_WAIT_TIMEOUT = 8
HUB_CONFIRMATIONS = 5
MAP_OPEN_RETRIES = 4

pyautogui.PAUSE = 0.02
pyautogui.FAILSAFE = True
pydirectinput.PAUSE = 0.02

active = threading.Event()
shutdown = threading.Event()
movement_lock = threading.Lock()
combat_active = threading.Event()  # prevents double-triggering combat
in_raid = threading.Event()        # true only while inside an active raid room

# ── Raid counter ─────────────────────────────────────────────────────────────
_raids_completed  = 0
_boss_bars_seen   = 0   # increments each time boss bar appears (most accurate raid count)
_session_start    = time.time()
_last_raid_start  = None
_last_raid_time   = 0.0


def is_active():
    return active.is_set() and not shutdown.is_set()


def release_movement_keys():
    with movement_lock:
        for key in ("w", "a", "s", "d"):
            try:
                pydirectinput.keyUp(key)
            except Exception:
                pass


def set_active(v):
    if v:
        active.set()
    else:
        active.clear()
        release_movement_keys()


def toggle():
    if active.is_set():
        set_active(False)
        print("[MACRO] PAUSED")
    else:
        active.set()
        print("[MACRO] RUNNING")


def emergency_stop():
    set_active(False)
    print("[MACRO] EMERGENCY STOP")


def print_mouse():
    x, y = pyautogui.position()
    print(f"[MOUSE] X={x}, Y={y}")


def focus_roblox():
    titles = [t for t in gw.getAllTitles() if t and "roblox" in t.lower()]
    if not titles:
        print("[WARN] Roblox window not found.")
        return False

    titles.sort(key=lambda t: ("studio" in t.lower(), len(t)))
    try:
        win = gw.getWindowsWithTitle(titles[0])[0]
        if win.isMinimized:
            win.restore()
            time.sleep(0.4)
        try:
            win.activate()
        except Exception:
            pass
        time.sleep(0.3)
        return True
    except Exception as exc:
        print("[WARN] Could not focus Roblox:", exc)
        return False


def screenshot_bgr():
    shot = pyautogui.screenshot()
    return cv2.cvtColor(np.array(shot), cv2.COLOR_RGB2BGR)


def load_template(path):
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(path)
    return img


TM = {k: load_template(v) for k, v in TEMPLATE_FILES.items()}


def multiscale_match(name, threshold=0.70, region=None, scales=None):
    """
    Match template at several sizes. Returns (x, y, score, scale).

    region = (left, top, right, bottom) in current screen coordinates.
    """
    screen = screenshot_bgr()
    full_h, full_w = screen.shape[:2]

    if region:
        l, t, r, b = region
        l = max(0, l); t = max(0, t)
        r = min(full_w, r); b = min(full_h, b)
        search = screen[t:b, l:r]
        offset_x, offset_y = l, t
    else:
        search = screen
        offset_x = offset_y = 0

    search_gray = cv2.cvtColor(search, cv2.COLOR_BGR2GRAY)
    template0 = TM[name]

    if scales is None:
        scales = (0.78, 0.86, 0.94, 1.0, 1.06, 1.14, 1.22)

    best = None

    for scale in scales:
        tw = max(8, int(template0.shape[1] * scale))
        th = max(8, int(template0.shape[0] * scale))

        if tw >= search.shape[1] or th >= search.shape[0]:
            continue

        tpl = cv2.resize(template0, (tw, th), interpolation=cv2.INTER_AREA)
        tpl_gray = cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY)

        result = cv2.matchTemplate(search_gray, tpl_gray, cv2.TM_CCOEFF_NORMED)
        _, score, _, loc = cv2.minMaxLoc(result)

        if best is None or score > best[2]:
            best = (
                offset_x + loc[0] + tw // 2,
                offset_y + loc[1] + th // 2,
                float(score),
                scale,
            )

    if best and best[2] >= threshold:
        return best
    return None


def move_click(x, y, label):
    """
    Move to a target and click using DirectInput.

    Roblox can ignore normal pyautogui mouse clicks even when the cursor
    visibly moves. pydirectinput mouseDown/mouseUp is much more reliable.
    """
    if not is_active():
        return False


    # Move visibly first.
    pyautogui.moveTo(x, y, duration=1.0, tween=pyautogui.easeInOutQuad)

    if not is_active():
        return False

    time.sleep(0.18)

    # Strong click sequence: DirectInput down/up, then a second click if needed.
    try:
        pydirectinput.mouseDown(button="left")
        time.sleep(0.08)
        pydirectinput.mouseUp(button="left")
    except TypeError:
        # Compatibility fallback for older pydirectinput versions.
        pydirectinput.mouseDown()
        time.sleep(0.08)
        pydirectinput.mouseUp()

    time.sleep(0.20)

    # One extra DirectInput click helps with Roblox UI elements that need
    # a fully focused click after the cursor has moved.
    try:
        pydirectinput.click(x=x, y=y, button="left")
    except TypeError:
        pydirectinput.click(x, y)

    time.sleep(0.45)
    return True


def scaled_click(ref_xy, label, cfg_x=0, cfg_y=0):
    """
    Click a target with smooth motion.
    If cfg_x/cfg_y are non-zero (user entered coords in launcher) use those.
    Otherwise scale the reference coord from 1920x1080 to the current resolution.
    """
    if cfg_x and cfg_y:
        return move_click(cfg_x, cfg_y, label)
    rx, ry = ref_xy
    res_w = _ri(_CFG, "total_w", 1920)
    res_h = _ri(_CFG, "total_h", 1080)
    sx = int(rx * res_w / REF_CLICK_W)
    sy = int(ry * res_h / REF_CLICK_H)
    return move_click(sx, sy, label)


def interruptible_hold(key, seconds):
    if not is_active():
        return
    with movement_lock:
        pydirectinput.keyDown(key)
    try:
        end = time.time() + seconds
        while time.time() < end and is_active():
            time.sleep(0.02)
    finally:
        with movement_lock:
            try:
                pydirectinput.keyUp(key)
            except Exception:
                pass



def interruptible_sleep(seconds):
    end = time.time() + seconds
    while time.time() < end:
        if not is_active():
            return False
        time.sleep(min(0.03, max(0.0, end - time.time())))
    return True


def wait_for_match(name, timeout, threshold, region=None, scales=None):
    end = time.time() + timeout
    while time.time() < end and is_active():
        m = multiscale_match(name, threshold, region, scales)
        if m:
            return m
        time.sleep(0.05)
    return None


def open_map():
    if not focus_roblox():
        return False

    for attempt in range(1, MAP_OPEN_RETRIES + 1):
        if not is_active():
            return False

        print(f"[1/6] Opening map... {attempt}/{MAP_OPEN_RETRIES}")
        pydirectinput.press("m")
        time.sleep(0.9)

        m = multiscale_match(
            "honored",
            threshold=THR_HONORED,
            region=R_OPEN_MAP_HONORED,
        )
        if m:
            print("[MAP] Map open.")
            return True

        time.sleep(0.35)

    return False


def click_honored_one():
    print("[2/6] Finding The Honored One...")
    if CLICK_HONORED_X and CLICK_HONORED_Y:
        if not move_click(CLICK_HONORED_X, CLICK_HONORED_Y, "The Honored One"):
            return False
        time.sleep(0.6)
        return True

    # Otherwise auto-detect via template matching.
    match = wait_for_match(
        "honored",
        timeout=5,
        threshold=THR_HONORED,
        region=R_CLICK_HONORED,
    )

    if not match:
        print("[ERROR] Could not locate The Honored One icon.")
        return False

    if not move_click(match[0], match[1], "The Honored One"):
        return False

    # After clicking, the detail panel should appear on the right.
    time.sleep(0.6)

    selected = wait_for_match(
        "honored_selected",
        timeout=3,
        threshold=THR_HONORED,
        region=R_HONORED_SELECTED,
    )

    # The exact selected-icon location can vary, so also accept the
    # appearance of the Teleport button as proof the click worked.
    teleport = multiscale_match(
        "teleport",
        threshold=THR_HONORED,
        region=R_TELEPORT_CHECK,
    )

    if selected or teleport:
        return True

    print("[WARN] First click did not open the detail panel. Clicking again.")
    return move_click(match[0], match[1], "The Honored One retry")


def click_teleport():
    print("[3/6] Finding Teleport...")
    if CLICK_TELEPORT_X and CLICK_TELEPORT_Y:
        return move_click(CLICK_TELEPORT_X, CLICK_TELEPORT_Y, "Teleport")

    # Otherwise auto-detect via template matching.
    match = wait_for_match(
        "teleport",
        timeout=5,
        threshold=THR_HONORED,
        region=R_TELEPORT_BTN,
        scales=(0.85, 0.92, 1.0, 1.08, 1.15),
    )

    if not match:
        print("[ERROR] Teleport button not found.")
        return False

    return move_click(match[0], match[1], "Teleport")


def click_return_button():
    """Smooth glide to Return button, sweep ±10px, left-click x5."""
    if not CLICK_RETURN_X or not CLICK_RETURN_Y:
        return
    cx, cy = CLICK_RETURN_X, CLICK_RETURN_Y
    focus_roblox()

    # Smooth glide in
    pyautogui.moveTo(cx, cy, duration=1.4, tween=pyautogui.easeInOutQuad)
    time.sleep(0.25)

    # Gentle ±10px sweep so Roblox registers the cursor over the button
    pyautogui.moveTo(cx - 10, cy, duration=0.18, tween=pyautogui.easeInOutQuad)
    time.sleep(0.06)
    pyautogui.moveTo(cx,      cy, duration=0.18, tween=pyautogui.easeInOutQuad)
    time.sleep(0.06)
    pyautogui.moveTo(cx + 10, cy, duration=0.18, tween=pyautogui.easeInOutQuad)
    time.sleep(0.06)
    pyautogui.moveTo(cx,      cy, duration=0.18, tween=pyautogui.easeInOutQuad)
    time.sleep(0.15)

    # Left-click x5 via DirectInput
    for _ in range(5):
        pydirectinput.moveTo(cx, cy)
        try:
            pydirectinput.mouseDown(button="left")
            time.sleep(0.07)
            pydirectinput.mouseUp(button="left")
        except TypeError:
            pydirectinput.mouseDown()
            time.sleep(0.07)
            pydirectinput.mouseUp()
        time.sleep(0.22)


def go_from_hub_to_structure():
    click_return_button()
    if not open_map():
        return False
    if not click_honored_one():
        return False
    if not click_teleport():
        return False

    print("[4/6] Teleporting...")
    time.sleep(7)
    if not is_active():
        return False

    focus_roblox()
    print("[4/6] Pressing F at structure...")
    pydirectinput.press("f")
    return True




def fallback_circle_template_match(screen):
    """
    Backup detector for cases where bloom/lighting makes the strict HSV ring
    contour disappear. Uses the saved circle templates at multiple scales and
    only searches the gameplay/ground region.

    Returns (x, y, confidence) or None.
    """
    if screen is None:
        return None

    h, w = screen.shape[:2]

    # Avoid most sky/UI while still allowing the ring to appear above or below
    # the avatar depending on camera perspective.
    left = int(w * 0.08)
    right = int(w * 0.94)
    top = int(h * FALLBACK_TOP)
    bottom = int(h * FALLBACK_BOTTOM)

    search = screen[top:bottom, left:right]
    if search.size == 0:
        return None

    search_gray = cv2.cvtColor(search, cv2.COLOR_BGR2GRAY)

    # v2 is the strongest/most recent ring reference; the older close template
    # is retained as a second chance for different apparent sizes.
    template_names = ("circle_v2", "circle_close", "circle", "circle_far")
    scales = (0.55, 0.68, 0.80, 0.92, 1.00, 1.10, 1.22, 1.36)

    best = None

    for name in template_names:
        template0 = TM.get(name)
        if template0 is None:
            continue

        for scale in scales:
            tw = max(12, int(template0.shape[1] * scale))
            th = max(8, int(template0.shape[0] * scale))

            if tw >= search.shape[1] or th >= search.shape[0]:
                continue

            tpl = cv2.resize(template0, (tw, th), interpolation=cv2.INTER_AREA)
            tpl_gray = cv2.cvtColor(tpl, cv2.COLOR_BGR2GRAY)

            result = cv2.matchTemplate(search_gray, tpl_gray, cv2.TM_CCOEFF_NORMED)
            _, score, _, loc = cv2.minMaxLoc(result)

            # Subpixel refinement: fit a 3x3 quadratic around the peak for a
            # more accurate centre than the raw integer location.
            px, py = loc[0], loc[1]
            rh, rw = result.shape
            if 1 <= py < rh - 1 and 1 <= px < rw - 1:
                patch = result[py - 1:py + 2, px - 1:px + 2].astype(np.float32)
                dx = (patch[1, 2] - patch[1, 0]) / (2 * (2 * patch[1, 1] - patch[1, 0] - patch[1, 2]) + 1e-6)
                dy = (patch[2, 1] - patch[0, 1]) / (2 * (2 * patch[1, 1] - patch[0, 1] - patch[2, 1]) + 1e-6)
                dx = max(-1.0, min(1.0, dx))
                dy = max(-1.0, min(1.0, dy))
            else:
                dx, dy = 0.0, 0.0

            cx = int(round(left + loc[0] + dx + tw / 2.0))
            cy = int(round(top  + loc[1] + dy + th / 2.0))

            # Prefer plausible flattened ring placements in the central
            # gameplay area. Keep the threshold deliberately conservative:
            # this is only a fallback after the strict HSV detector fails.
            centre_penalty = abs(cx - (w * 0.5)) / max(w * 0.5, 1.0)
            adjusted = float(score) - 0.035 * centre_penalty

            if best is None or adjusted > best[2]:
                best = (cx, cy, adjusted, float(score), name, scale)

    if best and best[3] >= 0.46:
        cx, cy, adjusted, raw_score, name, scale = best
        print(
            f"[CIRCLE] Template fallback: {name} center=({cx},{cy}) "
            f"score={raw_score:.3f} scale={scale:.2f}"
        )
        return cx, cy, raw_score * 10000.0

    if best:
        print(
            f"[CIRCLE] Template fallback rejected: best={best[4]} "
            f"score={best[3]:.3f}"
        )
    return None


def detect_blue_circle(allow_fallback=True):
    """
    Detect the glowing blue waiting ring and return (x, y, score, source), or None.

    v6.3 deliberately avoids using a raw 'bluest area wins' rule because the
    sky/background can also be blue. A valid target must look like the raid
    ring geometrically: a large, bright, horizontally-elongated cyan shape in
    the lower gameplay area.
    """
    screen = screenshot_bgr()
    if screen is None:
        return None

    h, w = screen.shape[:2]
    hsv = cv2.cvtColor(screen, cv2.COLOR_BGR2HSV)

    # The ring is extremely bright cyan. Requiring high value and reasonably
    # high saturation rejects most of the pale blue sky.
    lower = np.array([87, 118, 225], dtype=np.uint8)
    upper = np.array([110, 255, 255], dtype=np.uint8)
    mask = cv2.inRange(hsv, lower, upper)

    # Ignore UI/sky-heavy areas. The waiting ring should be on the ground,
    # normally in the lower ~2/3 of the gameplay view.
    mask[:int(h * MASK_TOP), :] = 0
    mask[int(h * MASK_BOTTOM):, :] = 0
    mask[:, :int(w * 0.05)] = 0
    mask[:, int(w * 0.95):] = 0

    # Join the glowing rim into one coherent horizontal object without
    # allowing huge background patches to merge together.
    close_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, close_kernel, iterations=1)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    candidates = []

    for contour in contours:
        area = float(cv2.contourArea(contour))
        if area < CONTOUR_AREA_MIN:
            continue

        x, y, cw, ch = cv2.boundingRect(contour)
        if cw < CONTOUR_W_MIN or ch < CONTOUR_H_MIN:
            continue

        aspect = cw / max(float(ch), 1.0)
        fill = area / max(float(cw * ch), 1.0)

        # The waiting circle appears as a flattened ellipse/ring.
        if not (1.65 <= aspect <= 6.0):
            continue

        # Reject giant sky/ground blobs and tiny skinny streaks.
        if cw > int(w * 0.55) or ch > int(h * 0.30):
            continue
        if not (0.18 <= fill <= 0.95):
            continue

        # Use image moments for a more accurate centroid than bounding box midpoint.
        M = cv2.moments(contour)
        if M["m00"] > 0:
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
        else:
            cx = x + cw // 2
            cy = y + ch // 2

        # Additional local check: the candidate box itself must contain a
        # meaningful amount of bright cyan, not just a chance contour edge.
        roi = mask[y:y + ch, x:x + cw]
        cyan_ratio = cv2.countNonZero(roi) / max(float(cw * ch), 1.0)
        if cyan_ratio < 0.12:
            continue

        # Score favors substantial, ring-shaped candidates and mildly favors
        # the lower half of the screen.
        lower_bonus = 1.0 + 0.35 * max(0.0, (cy / h) - 0.45)
        shape_bonus = min(aspect, 3.5)
        score = area * shape_bonus * lower_bonus

        candidates.append((cx, cy, score, x, y, cw, ch, aspect, cyan_ratio))

    if not candidates:
        if allow_fallback:
            print("[CIRCLE] Strict cyan contour not found; trying template fallback.")
            fallback = fallback_circle_template_match(screen)
            if fallback is not None:
                # Fourth field identifies this as a fallback-only target.
                # It may be used for steering, but MUST NOT reset the 10-second
                # failsafe timer.
                return fallback[0], fallback[1], fallback[2], "fallback"

            print("[CIRCLE] No ring found by strict or fallback detector.")
        else:
            print("[CIRCLE] No strict ring found during reveal movement.")
        return None

    best = max(candidates, key=lambda c: c[2])
    cx, cy, score, x, y, cw, ch, aspect, cyan_ratio = best

    print(
        f"[CIRCLE] Ring candidate center=({cx},{cy}) "
        f"box={cw}x{ch} aspect={aspect:.2f} cyan={cyan_ratio:.2f}"
    )

    # Fourth field marks this as a genuine strict cyan/geometry detection.
    return cx, cy, score, "strict"



def raid_countdown_started():
    """
    Detect the stable 'Starting in' message.

    Once this appears, Roblox has accepted the player into the waiting circle,
    so all movement must stop immediately.
    """
    match = multiscale_match(
        "starting_in",
        threshold=0.75,
        region=R_COUNTDOWN,
        scales=(0.75, 0.85, 0.95, 1.0, 1.05, 1.15, 1.25),
    )
    return match



def hold_with_countdown_watch(key, seconds, check_every=0.12):
    """
    Hold a movement key, but stop immediately if the raid countdown appears.

    This fixes the case where the initial A/S reposition briefly passes
    through the blue circle before the full movement finishes.
    """
    if not is_active():
        return False

    with movement_lock:
        pydirectinput.keyDown(key)

    start = time.time()
    try:
        while time.time() - start < seconds and is_active():
            countdown = raid_countdown_started()
            if countdown:
                print(f"[CIRCLE] Countdown appeared during '{key}' movement. Stopping immediately.")
                return True
            time.sleep(check_every)
    finally:
        with movement_lock:
            try:
                pydirectinput.keyUp(key)
            except Exception:
                pass

    return raid_countdown_started() is not None


class CircleVectorTracker:
    """
    Lightweight temporal tracker for the blue raid circle.

    It is not a neural-network model; it uses computer-vision detections,
    vector smoothing and short-horizon motion prediction. This gives us a
    much more stable target vector than reacting to each raw frame alone.
    """

    def __init__(self):
        self.pos = None
        self.vel = np.array([0.0, 0.0], dtype=np.float32)
        self.last_time = None
        self.last_seen = None

    def reset(self):
        self.pos = None
        self.vel[:] = 0.0
        self.last_time = None
        self.last_seen = None

    def update(self, detection):
        now = time.time()

        if detection is None:
            if self.pos is None or self.last_seen is None:
                return None
            if now - self.last_seen > VECTOR_LOST_TIMEOUT:
                self.reset()
                return None

            # Briefly coast using the estimated velocity if one frame is lost.
            dt = min(now - (self.last_time or now), 0.20)
            predicted = self.pos + self.vel * dt
            self.pos = predicted
            self.last_time = now
            return float(predicted[0]), float(predicted[1])

        measured = np.array([float(detection[0]), float(detection[1])], dtype=np.float32)

        if self.pos is None:
            self.pos = measured
            self.vel[:] = 0.0
        else:
            dt = max(0.02, min(now - (self.last_time or now), 0.50))
            raw_velocity = (measured - self.pos) / dt
            self.vel = (
                VECTOR_VELOCITY_ALPHA * raw_velocity
                + (1.0 - VECTOR_VELOCITY_ALPHA) * self.vel
            )
            self.pos = (
                VECTOR_ALPHA * measured
                + (1.0 - VECTOR_ALPHA) * self.pos
            )

        self.last_time = now
        self.last_seen = now

        predicted = self.pos + self.vel * VECTOR_PREDICT_SECONDS
        return float(predicted[0]), float(predicted[1])


def vector_step(distance):
    distance = abs(float(distance))
    if distance >= 260:
        return VECTOR_STEP_FAR
    if distance >= 145:
        return VECTOR_STEP_MEDIUM
    return VECTOR_STEP_NEAR


def vector_hold(key, seconds):
    """
    Perform one short steering pulse while watching for circle acceptance.
    """
    if not is_active():
        return False

    with movement_lock:
        pydirectinput.keyDown(key)

    try:
        end = time.time() + seconds
        while time.time() < end and is_active():
            if raid_countdown_started():
                print(f"[VECTOR] Countdown detected during {key.upper()} pulse.")
                return True
            time.sleep(0.025)
    finally:
        with movement_lock:
            try:
                pydirectinput.keyUp(key)
            except Exception:
                pass

    return raid_countdown_started() is not None


def initial_move_until_circle(key, seconds, label):
    """
    Perform the reveal movement while watching BOTH:
      1. strict ring detection, and
      2. the raid 'Starting in' countdown.

    The countdown is the strongest proof that the character has actually
    entered the waiting circle. If it appears during A/S movement, release the
    key immediately so the character cannot continue through and exit the ring.

    Returns:
      "countdown" -> Roblox accepted the player into the circle
      "ring"      -> ring confirmed visually on 2 consecutive strict frames
      None        -> movement duration completed without either condition
    """
    if not is_active():
        return None

    print(
        f"[VECTOR] Initial movement: {label} up to {seconds:.1f}s; "
        "watching ring + countdown."
    )

    with movement_lock:
        pydirectinput.keyDown(key)

    result = None
    ring_hits = 0

    try:
        end = time.time() + seconds

        while time.time() < end and is_active():
            # Highest-priority condition: Roblox itself says the player has
            # entered the circle. Stop BEFORE the movement can overshoot it.
            if raid_countdown_started():
                result = "countdown"
                print(
                    f"[VECTOR] Countdown appeared during initial {label}; "
                    "releasing movement immediately to prevent overshoot."
                )
                break

            target = detect_blue_circle(allow_fallback=False)

            if target is not None:
                ring_hits += 1
                if ring_hits >= 2:
                    result = "ring"
                    print(
                        f"[VECTOR] Ring confirmed during initial {label}; "
                        "stopping reveal movement and switching to vector targeting."
                    )
                    break
            else:
                ring_hits = 0

            time.sleep(0.025)

    finally:
        with movement_lock:
            try:
                pydirectinput.keyUp(key)
            except Exception:
                pass

    release_movement_keys()
    return result



def _hold_scanning_for_circle(key, seconds):
    """
    Hold a movement key while continuously scanning for the blue circle
    (with fallback). Returns the detection tuple the moment one is found,
    or None if the hold completed without finding anything.
    """
    if not is_active():
        return None

    with movement_lock:
        pydirectinput.keyDown(key)

    found = None
    try:
        end = time.time() + seconds
        while time.time() < end and is_active():
            det = detect_blue_circle(allow_fallback=True)
            if det is not None:
                print(f"[CIRCLE] Circle detected during '{key}' movement — stopping instantly.")
                found = det
                break
            time.sleep(0.05)
    finally:
        with movement_lock:
            try:
                pydirectinput.keyUp(key)
            except Exception:
                pass

    release_movement_keys()
    return found


def move_into_blue_circle(timeout=7):
    """
    v2.6: Simplified circle entry.
    - Holds A for 0.5s to position correctly after lobby loads (no scanning).
    - Holds S for 1.5s, scanning for the circle the whole time.
    - Stops S movement instantly if the circle is detected.
    - Detects the blue circle on screen using CV.
    - Moves the mouse to the center of the circle.
    - Presses E to teleport into it.
    - Waits for countdown or boss bar as confirmation.
    - Retries up to timeout seconds if circle not found.
    """
    release_movement_keys()
    interruptible_hold("a", 0.5)
    early = _hold_scanning_for_circle("s", 1.5)
    release_movement_keys()
    time.sleep(0.3)

    if early is not None:
        cx, cy = int(early[0]), int(early[1])
    else:
        cx, cy = None, None

    deadline = time.time() + timeout

    while time.time() < deadline and is_active():
        # Only countdown stops us early — boss bar check is after timeout.
        if raid_countdown_started():
            return True

        if early is not None:
            raw = early
            early = None
        else:
            raw = detect_blue_circle(allow_fallback=True)

        if raw is None:
            time.sleep(0.3)
            continue

        cx, cy = int(raw[0]), int(raw[1])
        print(f"[CIRCLE] Found at ({cx},{cy})")

        # Focus Roblox first so inputs register.
        focus_roblox()
        time.sleep(0.2)

        # Move mouse smoothly to circle center.
        pyautogui.moveTo(cx, cy, duration=1.2, tween=pyautogui.easeInOutQuad)
        time.sleep(0.3)

        # RMB via DirectInput so Roblox actually registers it.
        pydirectinput.moveTo(cx, cy)
        time.sleep(0.1)
        pydirectinput.mouseDown(button="right")
        time.sleep(0.1)
        pydirectinput.mouseUp(button="right")
        time.sleep(0.3)

        time.sleep(0.4)

        # Now press E to enter the circle.
        pydirectinput.press("e")
        time.sleep(0.8)

        # Wait for countdown confirmation — up to 4 seconds after E press.
        for _ in range(14):
            if not is_active():
                return False
            if raid_countdown_started():
                return True
            if multiscale_match("boss", threshold=THR_BOSS, region=R_BOSS_BAR):
                return True
            time.sleep(0.3)

        # E didn't work, try again.

    # Timeout reached — check if boss bar appeared (raid already started).
    if multiscale_match("boss", threshold=THR_BOSS, region=R_BOSS_BAR):
        return True

    print("[CIRCLE] Timed out — restarting.")
    return False



def create_calamity_raid():
    print("[5/6] Creating Calamity raid...")
    time.sleep(1)
    scaled_click(CALAMITY_REF, "Calamity", CLICK_CALAMITY_X, CLICK_CALAMITY_Y)
    time.sleep(1.5)

    scaled_click(CREATE_REF, "Create", CLICK_CREATE_X, CLICK_CREATE_Y)
    time.sleep(0.8)

    focus_roblox()
    print("[6/6] Entering circle...")
    return move_into_blue_circle()

    
def wait_for_raid_room():
    global _boss_bars_seen
    match = wait_for_match(
        "boss",
        timeout=RAID_START_TIMEOUT,
        threshold=THR_BOSS,
        region=R_BOSS_BAR,
    )
    if match:
        print("[RAID] Raid started!")
        focus_roblox()
        in_raid.set()
        return True
    print("[RAID] Raid room not detected — retrying.")
    return False


def _boss_counter():
    """
    Dedicated thread: ONLY counts boss bar appearances.
    Completely independent of combat. Sees bar appear → count →
    wait for it to disappear → repeat.
    """
    global _boss_bars_seen
    bar_visible = False

    while not shutdown.is_set():
        if not active.is_set():
            time.sleep(0.1)
            continue

        match = multiscale_match("boss", threshold=THR_BOSS, region=R_BOSS_BAR)

        if match and not bar_visible:
            bar_visible = True
            _boss_bars_seen += 1
        elif not match and bar_visible:
            bar_visible = False

        time.sleep(0.05)


def boss_watcher():
    """
    Background thread: handles combat only.
    Detects boss bar, starts spam_until_hub, repeats.
    """

    while not shutdown.is_set():
        if not active.is_set():
            time.sleep(0.1)
            continue

        if combat_active.is_set():
            time.sleep(0.1)
            continue

        match = multiscale_match("boss", threshold=THR_BOSS, region=R_BOSS_BAR)
        if not match:
            time.sleep(0.05)
            continue

        if not combat_active.is_set() and is_active():
            focus_roblox()
            try:
                pydirectinput.click(button="middle")
            except Exception:
                pass
            time.sleep(0.2)
            combat_active.set()
            in_raid.set()
            try:
                spam_until_hub()
            finally:
                combat_active.clear()

        time.sleep(0.05)


def hub_visible():
    return multiscale_match(
        "hub",
        threshold=THR_HUB,
        region=R_HUB,
    ) is not None


def spam_until_hub():
    """
    Combat rotation built from user-selected attacks.
    All keys are included if the player enabled them in settings.
    Y only fires at end-of-hub if Ten Shadows is ticked.
    """
    # Build rotation from cfg — only keys the user ticked
    # Y is excluded from rotation when Ten Shadows is active (fires 3x at end-of-hub instead)
    rotation_keys = ("z", "v", "t", "f", "c", "x", "r") if TEN_SHADOWS else ("z", "v", "y", "t", "f", "c", "x", "r")
    rotation = [k for k in rotation_keys if ATTACK_KEYS.get(k, False)]
    confirmations = 0
    last_check = 0.0

    focus_roblox()
    print(f"[COMBAT] Ability spam started. Rotation: {rotation}")

    while is_active():
        # Normal rotation
        for key in rotation:
            if not is_active():
                return
            pydirectinput.press(key)
            time.sleep(ABILITY_KEY_DELAY)

        # Hub detection
        if time.time() - last_check >= 1.3:
            last_check = time.time()

            if hub_visible():
                confirmations += 1
                if confirmations >= HUB_CONFIRMATIONS:
                    print(f"[HUB] {HUB_CONFIRMATIONS}/{HUB_CONFIRMATIONS} Hub detected.")
                    print("[HUB] Returning to hub...")
                    time.sleep(1.6)
                    print("[HUB] Returned to hub.")
                    if TEN_SHADOWS:
                        print("[HUB] Pressing Y x3 (Ten Shadows)...")
                        for _ in range(3):
                            pydirectinput.press("y")
                            time.sleep(0.3)
                    return
            else:
                confirmations = 0



def run_cycle():
    global _raids_completed, _last_raid_start
    in_raid.clear()
    _last_raid_start = time.time()

    if not go_from_hub_to_structure():
        return False
    if not create_calamity_raid():
        return False
    if not wait_for_raid_room():
        return False

    # Block here until hub is visible — do NOT return until the raid
    # kicks us back to hub. This is the ONLY exit condition.
    if not combat_active.is_set():
        combat_active.set()
        try:
            spam_until_hub()
        finally:
            combat_active.clear()
            in_raid.clear()
    else:
        # Watcher started combat — wait here until it fully finishes.
        while combat_active.is_set() and is_active():
            time.sleep(0.5)
        in_raid.clear()

    _raids_completed += 1
    _last_raid_time = time.time() - _last_raid_start

    return is_active()


def reset_character():
    """
    Press ESC, R, Enter to respawn, then wait 5 seconds for the game to load.
    Used when a cycle fails so the character is in a clean state before retrying.
    """
    focus_roblox()
    pydirectinput.press("esc")
    time.sleep(0.5)
    pydirectinput.press("r")
    time.sleep(0.5)
    pydirectinput.press("enter")
    time.sleep(5.0)
    focus_roblox()


def controller():
    while not shutdown.is_set():
        if not active.is_set():
            time.sleep(0.08)
            continue

        print_header()
        print("========== NEW RAID CYCLE ==========")

        try:
            success = run_cycle()
        except pyautogui.FailSafeException:
            print("[STOP] Mouse fail-safe triggered.")
            emergency_stop()
            continue
        except Exception as exc:
            print("[ERROR]", repr(exc))
            success = False

        if not active.is_set():
            continue

        if not success:
            reset_character()

        print("[LOOP] Starting new loop in 3s...")
        end = time.time() + 3
        while time.time() < end and active.is_set():
            time.sleep(0.05)


def _stats_line():
    """Return the current stats as a formatted string."""
    session_time = time.time() - _session_start
    h, rem = divmod(int(session_time), 3600)
    m, s   = divmod(rem, 60)
    last   = f"{_last_raid_time:.0f}s" if _last_raid_time > 0 else "--"
    return (
        f"  Raids      : {_raids_completed}  |  "
        f"Last: {last}  |  "
        f"Session: {h:02d}:{m:02d}:{s:02d}"
    )


def _stats_title_updater():
    """
    Background thread: updates the CMD window title bar every second
    with live raid stats.
    """
    while not shutdown.is_set():
        ctypes.windll.kernel32.SetConsoleTitleW("THE HONORED ONE  —  " + _stats_line().strip())
        time.sleep(1)


def print_header():
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()
    print("=" * 47)
    print(" THE HONORED ONE - AUTO CALAMITY RAID v2.6")
    print("          ᴍᴀᴅᴇ ʙʏ ᴅɪᴀᴍᴏɴᴅ")
    print("=" * 47)
    res_w = _ri(_CFG, "total_w", 3440)
    res_h = _ri(_CFG, "total_h", 1440)
    dom   = "ON" if ATTACK_KEYS.get("t", False) else "OFF"
    print(f"  Resolution : {res_w}x{res_h}")
    print(f"  Domain     : {dom}")
    print()


def _raid_counter_window():
    """
    Small always-on-top tkinter window positioned bottom-right of the screen.
    Shows live raid stats and updates every second.
    Only runs if RAID_COUNTER_ENABLED is True.
    """
    import tkinter as tk

    BG_W   = "#111111"
    FG_W   = "#ffffff"
    MUT_W  = "#888888"
    ACC_W  = "#3b82d4"

    root = tk.Tk()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.attributes("-alpha", 0.92)
    root.configure(bg=BG_W)

    W, H = 280, 130
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    root.geometry(f"{W}x{H}+{sw - W - 12}+{sh - H - 80}")

    tk.Label(root, text="THE HONORED ONE", bg=BG_W, fg=ACC_W,
             font=("Segoe UI", 9, "bold")).pack(pady=(8, 0))

    boss_lbl = tk.Label(root, text="Raids     : 0",
                        bg=BG_W, fg="#44ccff", font=("Consolas", 9))
    boss_lbl.pack(anchor="w", padx=14)

    raids_lbl  = tk.Label(root, text="Cycles   : 0",
                          bg=BG_W, fg=FG_W, font=("Consolas", 9))
    raids_lbl.pack(anchor="w", padx=14)

    last_lbl   = tk.Label(root, text="Last     : --",
                          bg=BG_W, fg=FG_W, font=("Consolas", 9))
    last_lbl.pack(anchor="w", padx=14)

    session_lbl = tk.Label(root, text="Session  : 00:00:00",
                           bg=BG_W, fg=FG_W, font=("Consolas", 9))
    session_lbl.pack(anchor="w", padx=14)

    tk.Label(root, text="drag to move", bg=BG_W, fg=MUT_W,
             font=("Segoe UI", 7)).pack(pady=(4, 0))

    # Drag to move
    _drag = {"x": 0, "y": 0}
    def on_drag_start(e):
        _drag["x"] = e.x
        _drag["y"] = e.y
    def on_drag_move(e):
        x = root.winfo_x() + e.x - _drag["x"]
        y = root.winfo_y() + e.y - _drag["y"]
        root.geometry(f"+{x}+{y}")
    root.bind("<ButtonPress-1>", on_drag_start)
    root.bind("<B1-Motion>", on_drag_move)

    def tick():
        if shutdown.is_set():
            root.destroy()
            return
        session_time = time.time() - _session_start
        h, rem = divmod(int(session_time), 3600)
        m, s   = divmod(rem, 60)
        last   = f"{_last_raid_time:.0f}s" if _last_raid_time > 0 else "--"
        boss_lbl.config(text=f"Raids     : {_boss_bars_seen}")
        raids_lbl.config(text=f"Cycles   : {_raids_completed}")
        last_lbl.config(text=f"Last     : {last}")
        session_lbl.config(text=f"Session  : {h:02d}:{m:02d}:{s:02d}")
        root.after(1000, tick)

    tick()
    root.mainloop()


def main():
    print_header()
    print("F6 = Start / Pause")
    print("F7 = Emergency Stop")
    print("F9 = Mouse position")
    print()

    keyboard.add_hotkey("f6", toggle, suppress=False)
    keyboard.add_hotkey("f7", emergency_stop, suppress=False)
    keyboard.add_hotkey("f9", print_mouse, suppress=False)

    threading.Thread(target=controller, daemon=True).start()
    threading.Thread(target=boss_watcher, daemon=True).start()
    threading.Thread(target=_boss_counter, daemon=True).start()
    threading.Thread(target=_stats_title_updater, daemon=True).start()

    if RAID_COUNTER_ENABLED:
        threading.Thread(target=_raid_counter_window, daemon=True).start()

    try:
        while True:
            time.sleep(0.25)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown.set()
        set_active(False)
        keyboard.unhook_all()


if __name__ == "__main__":
    main()