@echo off
title Build Setup EXE
cd /d "%~dp0"

where py >nul 2>&1
if %errorlevel%==0 (
    set "PYTHON=py"
) else (
    set "PYTHON=python"
)

echo Installing PyInstaller...
%PYTHON% -m pip install pyinstaller

echo Building HonoredOne_Setup_and_Run.exe...
%PYTHON% -m PyInstaller --onefile --console --name HonoredOne_Setup_and_Run setup_launcher.py

if exist "dist\HonoredOne_Setup_and_Run.exe" (
    copy /Y "dist\HonoredOne_Setup_and_Run.exe" ".\HonoredOne_Setup_and_Run.exe" >nul
    echo.
    echo Created:
    echo   HonoredOne_Setup_and_Run.exe
) else (
    echo Build failed.
)

pause
