@echo off
title Honored One Macro v6.3 - Setup and Run
cd /d "%~dp0"

echo ===============================================
echo   Honored One Macro v6.3 - Setup and Run
echo ===============================================
echo.

where py >nul 2>&1
if %errorlevel%==0 (
    set "PYTHON=py"
) else (
    where python >nul 2>&1
    if %errorlevel%==0 (
        set "PYTHON=python"
    ) else (
        echo Python was not found.
        echo Install Python from https://www.python.org/downloads/
        echo Make sure "Add Python to PATH" is checked.
        pause
        exit /b 1
    )
)

echo Installing/updating requirements...
%PYTHON% -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo Requirement installation failed.
    pause
    exit /b 1
)

echo.
echo Starting macro...
%PYTHON% honored_one_macro_v6_3.py

echo.
echo Macro closed.
pause
